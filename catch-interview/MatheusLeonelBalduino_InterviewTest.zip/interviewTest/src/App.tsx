import styles from "./App.module.css";
import { Heading } from "./components/Heading/Heading";
import { Header } from "./components/Header/Header";
import { Section } from "./components/Section/Section";
import { UnorderedList } from "./components/UnorderedList/UnorderedList";
import { ListItem } from "./components/ListItem/ListItem";
import { AppointmentForm, AppointmentFormSchema } from "./forms/AppointmentForm";
import { useAPI } from "./hooks/useAPI";
import { ErrorMessage } from "./components/ErrorMessage/ErrorMessage";
import { Button } from "./components/Button/Button";
import { useCallback } from "react";

function App() {
	const { store, actions } = useAPI()
	const onSubmit = useCallback(({ name, startTime, endTime }: AppointmentFormSchema) => actions.post({
		name,
		startTime: startTime.getTime(),
		endTime: endTime.getTime(),
	}), [actions])

	return (
		<div className={styles.app}>
			<Header>
				<Heading>Appointments --- Matheus Leonel Balduino - @mathbalduino</Heading>
			</Header>
			<main className={styles.content}>
				<AppointmentForm error={actions.error} loading={actions.loading} onSuccess={onSubmit} />
				<Section>
					<Heading level="h2" className={styles.textCenter}>Existing Appointments</Heading>
					{store.loading && <p>Loading...</p>}
					{store.error && (
						<>
							<ErrorMessage>{store.error}</ErrorMessage>
							<Button onClick={() => store.fetch()}>Try again</Button>
						</>
					)}
					{!store.error && store.data?.length === 0 && <p>There's no appointments</p>}
					{!store.error && store.data && store.data.length > 0 && (
						<UnorderedList>
							{store.data.map(appointment => (
								<ListItem key={appointment.endTime}>
									<b>{appointment.name}</b>
									<p>
										{new Date(appointment.startTime).toDateString()} - {new Date(appointment.endTime).toDateString()}
									</p>
								</ListItem>
							))}
						</UnorderedList>
					)}
				</Section>
			</main>
		</div>
	);
}

export default App;
