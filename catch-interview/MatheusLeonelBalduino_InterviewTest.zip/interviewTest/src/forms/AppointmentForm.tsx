import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import * as yup from 'yup'
import { Paper } from '../components/Paper/Paper'
import { Heading } from '../components/Heading/Heading'
import { Input } from '../components/Input/Input'
import { Button } from '../components/Button/Button'
import { ErrorMessage } from '../components/ErrorMessage/ErrorMessage'
import { useEffect } from 'react'

export type AppointmentFormSchema = yup.InferType<typeof validationSchema>

export interface AppointmentFormProps {
    onSuccess: (form: AppointmentFormSchema) => Promise<any>
    onFailure?: () => void
    error?: string
    loading?: boolean
}

export const AppointmentForm = ({ onSuccess, onFailure, error, loading }: AppointmentFormProps) => {
    const { register, handleSubmit, reset, formState: { errors, isValid, isSubmitting, isDirty, isSubmitted, isSubmitSuccessful } } = useForm<AppointmentFormSchema>({
        resolver: yupResolver(validationSchema),
        mode: 'onBlur'
    })
    useEffect(() => { isSubmitSuccessful && reset() }, [isSubmitSuccessful, reset])
    return (
        <>
            {((!isValid && isDirty && isSubmitted) || error) && <ErrorMessage>{error || 'The form is invalid, please fill correctly'}</ErrorMessage>}
            <form onSubmit={handleSubmit(onSuccess, onFailure)}>
                <Paper>
                    <Heading level={'h2'}>Create an appointment</Heading>
                    <Input {...register('name')} error={errors.name?.message} label="Your name" placeholder="John Smith" />
                    <Input {...register('startTime')} error={errors.startTime?.message} label="Start Time" type="datetime-local" />
                    <Input {...register('endTime')} error={errors.endTime?.message} label="End Time" type="datetime-local" />
                    <Button type="submit" disabled={!isValid || isSubmitting || loading}>{loading ? 'Loading...' : 'Submit Request'}</Button>
                </Paper>
            </form>
        </>
    )
}

const dateMsg = 'Please, enter a valid date'
const requiredMsg = 'This field is required'
const validationSchema = yup.object({
    name: yup
        .string()
        .trim()
        .required(requiredMsg),
    startTime: yup
        .date()
        .typeError(dateMsg)
        .required(requiredMsg),
    endTime: yup
        .date()
        .typeError(dateMsg)
        .min(yup.ref('startTime'), "End date can't be before start date")
        .required(requiredMsg),
})
