import styles from "./ListItem.module.css";
import { LiHTMLAttributes, PropsWithChildren } from "react";

export interface ListItemProps extends LiHTMLAttributes<HTMLLIElement> {}

export const ListItem = ({ children, ...liProps }: PropsWithChildren<ListItemProps>) => (
    <li 
        {...liProps}
        className={`${styles.appointment} ${liProps.className || ''}`}
    >
        {children}
    </li>
)
