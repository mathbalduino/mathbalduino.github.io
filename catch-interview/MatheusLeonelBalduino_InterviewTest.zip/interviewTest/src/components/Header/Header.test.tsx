import { render, screen } from "@testing-library/react";
import { Header } from "./Header";

describe("<Header />", () => {
	it('Renders correctly', () => {
        const msg = 'Header Text'
        render(<Header>{msg}</Header>);
        const headerMsgElement = screen.getByText(msg, { selector: "header" });
        expect(headerMsgElement).toBeInTheDocument();
    })
	it('Have the default classname', () => {
        const msg = 'Header Text'
        render(<Header>{msg}</Header>);
        const headerMsgElement = screen.getByText(msg, { selector: "header" });
        expect(headerMsgElement).toHaveClass('header');
    })
	it('Have the default classname AND the custom ones', () => {
        const classnames = ['custom-classname', 'another-one']
        const msg = 'Header Text'
        render(<Header className={classnames.join(' ')}>{msg}</Header>);
        const headerMsgElement = screen.getByText(msg, { selector: "header" });
        expect(headerMsgElement).toHaveClass('header');
        classnames.forEach(classname => expect(headerMsgElement).toHaveClass(classname))
    })
});
