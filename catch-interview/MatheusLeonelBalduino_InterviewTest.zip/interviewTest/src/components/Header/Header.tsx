import { HTMLAttributes } from "react";
import styles from "./Header.module.css";

export interface HeaderProps extends HTMLAttributes<HTMLElement> {}

export const Header = ({ children, ...headerProps }: HeaderProps) => (
    <header
        {...headerProps}
        className={`${styles.header} ${headerProps.className || ''}`}
    >
        {children}
    </header>
)
