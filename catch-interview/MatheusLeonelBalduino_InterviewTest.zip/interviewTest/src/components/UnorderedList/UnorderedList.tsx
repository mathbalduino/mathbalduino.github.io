import { HTMLAttributes } from "react";
import styles from "./UnorderedList.module.css";

export interface UnorderedListProps extends HTMLAttributes<HTMLUListElement> {}

export const UnorderedList = ({ children, ...ulProps }: UnorderedListProps) => (
    <ul
        {...ulProps}
        className={`${styles.appointments} ${ulProps.className}`}
    >
        {children}
    </ul>
)
