import { render, screen } from "@testing-library/react";
import { ErrorMessage } from "./ErrorMessage";

describe("<ErrorMessage />", () => {
	it('Renders correctly', () => {
        const msg = 'Error Text'
        render(<ErrorMessage>{msg}</ErrorMessage>);
        const errorMsgElement = screen.getByText(msg, { selector: "p" });
        expect(errorMsgElement).toBeInTheDocument();
    })
	it('Have the default classname', () => {
        const msg = 'Error Text'
        render(<ErrorMessage>{msg}</ErrorMessage>);
        const errorMsgElement = screen.getByText((_, element) => element?.className === 'error');
        expect(errorMsgElement).toBeInTheDocument();
    })
});
