import styles from "./ErrorMessage.module.css";

export interface ErrorMessageProps {
    children: string
}

export const ErrorMessage = ({ children }: ErrorMessageProps) => (
    <div className={styles.error} aria-live="polite">
        <p>{children}</p>
    </div>
)
