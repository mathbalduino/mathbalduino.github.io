import { HTMLAttributes } from "react";
import styles from "./Section.module.css";

export interface SectionProps extends HTMLAttributes<HTMLElement> {}

export const Section = ({ children, ...sectionProps }: SectionProps) => (
    <section
        {...sectionProps}
        className={`${styles.appointmentsContainer} ${sectionProps.className || ''}`}
    >
        {children}
    </section>
)
