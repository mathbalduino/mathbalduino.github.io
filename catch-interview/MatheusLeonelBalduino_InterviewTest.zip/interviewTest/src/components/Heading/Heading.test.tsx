import { render, screen } from "@testing-library/react";
import { Heading } from "./Heading";

describe("<Heading />", () => {
	it('Renders correctly', () => {
        const msg = 'Heading Text'
        render(<Heading>{msg}</Heading>);
        const headerMsgElement = screen.getByText(msg, { selector: "h1" });
        expect(headerMsgElement).toBeInTheDocument();
    })
	it('Have the default classname', () => {
        const msg = 'Header Text'
        render(<Heading>{msg}</Heading>);
        const headerMsgElement = screen.getByText(msg, { selector: "h1" });
        expect(headerMsgElement).toHaveClass('header1');
    })
	it('Have the default classname AND the custom ones', () => {
        const classnames = ['custom-classname', 'another-one']
        const msg = 'Header Text'
        render(<Heading className={classnames.join(' ')}>{msg}</Heading>);
        const headerMsgElement = screen.getByText(msg, { selector: "h1" });
        expect(headerMsgElement).toHaveClass('header1');
        classnames.forEach(classname => expect(headerMsgElement).toHaveClass(classname))
    })
	it('Renders correctly h2', () => {
        const msg = 'Heading Text'
        render(<Heading level="h2">{msg}</Heading>);
        const headerMsgElement = screen.getByText(msg, { selector: "h2" });
        expect(headerMsgElement).toBeInTheDocument();
        expect(headerMsgElement).toHaveClass('header2');
    })
});
