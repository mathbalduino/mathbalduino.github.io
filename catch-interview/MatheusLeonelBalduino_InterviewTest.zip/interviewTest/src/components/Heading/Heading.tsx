import { HTMLAttributes, PropsWithChildren } from "react";
import styles from "./Heading.module.css";

export interface HeadingProps extends HTMLAttributes<HTMLHeadingElement> {
    level?: keyof (typeof headings)
}

export const Heading = ({ level, ...headingProps }: PropsWithChildren<HeadingProps>) => 
    headings[level || 'h1'](headingProps)

const headings = {
    'h1': ({ children, ...props }: HTMLAttributes<HTMLHeadingElement>) => 
        <h1 className={`${styles.header1} ${props.className || ''}`}>{children}</h1>,
    'h2': ({ children, ...props }: HTMLAttributes<HTMLHeadingElement>) => 
        <h2 className={`${styles.header2} ${props.className || ''}`}>{children}</h2>,
} as const
