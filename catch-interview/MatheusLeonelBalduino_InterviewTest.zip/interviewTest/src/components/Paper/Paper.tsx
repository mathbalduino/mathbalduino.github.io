import { PropsWithChildren } from "react";
import styles from "./Paper.module.css";

export interface PaperProps {}

export const Paper = ({ children }: PropsWithChildren<PaperProps>) => (
    <div className={styles.form}>
        {children}
    </div>
)
