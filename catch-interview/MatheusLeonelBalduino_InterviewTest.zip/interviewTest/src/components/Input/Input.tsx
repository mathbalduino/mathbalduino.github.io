import { forwardRef, InputHTMLAttributes } from "react";
import styles from "./Input.module.css";

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
    label: string
    name: string
    error?: string
}

export const Input = forwardRef<HTMLInputElement, InputProps>(({ label, name, error, ...inputProps }: InputProps, ref) => (
    <div className={styles.label}>
        <label htmlFor={name} className={`${styles.labelText} ${error ? styles.labelError : ''}`}>{label}</label>
        {error && <p className={styles.errorLabel}>{error}</p>}
        <input
            type={'text'}
            {...inputProps}
            name={name}
            id={name}
            className={`${styles.input} ${error ? styles.inputError : ''} ${inputProps.className || ''}`}
            ref={ref}
        />
    </div>
))
