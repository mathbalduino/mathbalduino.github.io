import { render, screen } from "@testing-library/react";
import { Input } from "./Input";

describe("<Input />", () => {
	it('Renders label and input correctly', () => {
        const name = 'customName'
        const label = 'My Label'
        render(<form><Input name={name} label={label} /></form>);
        const labelElement = screen.getByText(label, { selector: "label" });
        expect(labelElement).toBeInTheDocument();
        const inputElement = screen.getByLabelText(label, { selector: "input" });
        expect(inputElement).toBeInTheDocument();
    })
	it('Renders error, if present, correctly', () => {
        const name = 'customName'
        const label = 'My Label'
        const error = 'Error'
        render(<form><Input name={name} error={error} label={label} /></form>);
        const errorElement = screen.getByText(error, { selector: "p" });
        expect(errorElement).toBeInTheDocument();
    })
	it('Have the default classnames', () => {
        const name = 'customName'
        const label = 'My Label'
        render(<form><Input name={name} label={label} /></form>);
        const labelElement = screen.getByText(label, { selector: "label" });
        expect(labelElement).toHaveClass('labelText');
        const inputElement = screen.getByLabelText(label, { selector: "input" });
        expect(inputElement).toHaveClass('input');
    })
});
