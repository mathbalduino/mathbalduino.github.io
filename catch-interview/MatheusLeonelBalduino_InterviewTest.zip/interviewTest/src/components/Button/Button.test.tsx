import { render, screen } from "@testing-library/react";
import { Button } from "./Button";

describe("<Button />", () => {
	it('Renders correctly', () => {
        const msg = 'Button Text'
        render(<Button>{msg}</Button>);
        const buttonElement = screen.getByText(msg, { selector: "button" });
        expect(buttonElement).toBeInTheDocument();
    })
	it('Have the default classname', () => {
        const msg = 'Button Text'
        render(<Button>{msg}</Button>);
        const buttonElement = screen.getByText(msg, { selector: "button" });
        expect(buttonElement).toHaveClass('button');
    })
	it('Have the default classname AND the custom ones', () => {
        const classnames = ['custom-classname', 'another-one']
        const msg = 'Button Text'
        render(<Button className={classnames.join(' ')}>{msg}</Button>);
        const buttonElement = screen.getByText(msg, { selector: "button" });
        expect(buttonElement).toHaveClass('button');
        classnames.forEach(classname => expect(buttonElement).toHaveClass(classname))
    })
});
