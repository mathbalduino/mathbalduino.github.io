import { ButtonHTMLAttributes, PropsWithChildren } from "react";
import styles from "./Button.module.css";

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {}

export const Button = ({ children, ...buttonProps }: PropsWithChildren<ButtonProps>) => (
    <button
        {...buttonProps}
        className={`${styles.button} ${buttonProps.className || ''}`}
    >
        {children}
    </button>
)
