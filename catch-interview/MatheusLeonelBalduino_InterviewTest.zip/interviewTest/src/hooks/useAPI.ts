import { useCallback, useEffect, useState } from "react";
import { Appointment, useAppointmentsApi } from "../useAppointmentsApi";

const useStore = <T>() => {
    const [data, setData] = useState<T>()
    const [error, setError] = useState<string>()
    const [loading, setLoading] = useState(false)
    return {
        data, setData,
        error, setError,
        loading, setLoading
    }
}

export const useAPI = () => {
	const API = useAppointmentsApi();
    const store = useStore<Appointment[]>()
    const actions = useStore<void>()

    const fetch = useCallback(() => {
        store.setLoading(true)
        store.setData(undefined)
        store.setError(undefined)
        API.get()
            .then(({ success, appointments }) => {
                // eslint-disable-next-line no-throw-literal
                if (!success) throw "Unexpected error when fetching appointments"
                store.setData(appointments.slice())
            })
            .catch(store.setError)
            .finally(() => store.setLoading(false))
    }, [API, store])

    const post = useCallback<typeof API.post>(newAppointment => {
        const hasOverlap = store.data?.find(storedAppointment => 
            (storedAppointment.endTime > newAppointment.startTime && storedAppointment.endTime < newAppointment.endTime)
            || (storedAppointment.startTime > newAppointment.startTime && storedAppointment.startTime < newAppointment.endTime))
        if (hasOverlap) {
            const msg = `This appointment overlaps with ${hasOverlap.name}'s appointment`
            actions.setError(msg)
            return Promise.reject(msg) // ignored on purpose
        }

        actions.setLoading(true)
        actions.setError(undefined)
        return API.post(newAppointment)
            .then(data => {
                // eslint-disable-next-line no-throw-literal
                if (!data.success) throw "Unexpected error while saving new appointment"
                if (store.error) fetch()
                store.setData(prev => prev ? [...prev, newAppointment] : [newAppointment])
                return data
            })
            .catch(e => {
                actions.setError(e)
                throw e
                
                // eslint-disable-next-line no-unreachable
                return e // just to satisfy TypeScript
            })
            .finally(() => 
                actions.setLoading(false))
    }, [API, store, actions, fetch])

    // eslint-disable-next-line react-hooks/exhaustive-deps
    useEffect(() => void fetch(), [])

    return {
        store: {
            data: store.data,
            error: store.error,
            loading: store.loading,
            fetch,
        },
        actions: {
            error: actions.error,
            loading: actions.loading,
            post,
        }
    }
}
